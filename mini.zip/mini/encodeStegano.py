#!/usr/bin/env python
# coding: utf-8

# In[1]:


import cv2

img = cv2.imread('input.png')

'''
cv2.imshow('input',img)
cv2.waitKey()
cv2.destroyAllWindows()
'''

height,width,channels = img.shape

height,width,channels

def splittobgr(val):
    b=(val&0xE0)>>5
    g=(val&0x1C)>>2
    r=(val&0x3)
    return ([b,g,r])

msg=input('Enter your message:')
msglen = len(msg)

bitlist=[]
for i in range(msglen):
    bitlist.append(splittobgr(ord(msg[i])))

firstbit = splittobgr(msglen)

def clearLSB3(val):
    return (val&0xF8)

def encode(imgbit,msgbit):
    return (msgbit | clearLSB3(imgbit))

for i in range(3):
    img[0,0][i]=encode(img[0,0][i],firstbit[i])

c=0
f=0
for i in range(height):
    for j in range(1,width):
        if (c==msglen):
            f=1
            break
        for k in range(3):
            img[i,j][k]=encode(img[i,j][k],bitlist[c][k])
        print(img[i,j])
        c+=1
    if(f==1):
        break

cv2.imwrite('output.png',img)
